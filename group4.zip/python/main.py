import argparse
from python.tcpServer import werewolf_player, vampire_player


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("-i", "--ipAddress", required=True, type=str, help="The game server ip")
    ap.add_argument("-p", "--port", required=True, type=str, help="The game server port")
    ap.add_argument("-r", "--role", required=True, type=str, help="Our player role")

    args = vars(ap.parse_args())

    if args['role'] == 'W':
        werewolf_player.werewolf_game(args['ipAddress'], args['port'])
    if args['role'] == 'V':
        vampire_player.vampire_game(args['ipAddress'], args['port'])
    else:
        raise ValueError('Unkown player!')