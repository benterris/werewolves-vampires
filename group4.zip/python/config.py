# Connections
server_ip = "127.0.0.1"
server_port = 5555
trace = True
map = ""

# Alpha-beta
MAX_DEPTH = 4
MAX_ACTIONS = 100
MAX_TIME_MILLISECONDS = 1500
