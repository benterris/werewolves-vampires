# Challenge IA

Repo of the winning team
